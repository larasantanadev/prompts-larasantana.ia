# Sistema de Cortes

Plugin para o Claude que corta uma live em vários vídeos verticais prontos para postar.

Como usar: instale o plugin (Configurações → Plugins → Upload), anexe a live e peça "corta essa live em cinco".
Use só lives de quem autorizou. O Claude precisa de um ambiente que rode código (ffmpeg e Python).
Por @larasantana.ia
