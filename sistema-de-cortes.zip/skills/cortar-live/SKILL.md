---
name: cortar-live
description: Use quando a pessoa pedir para cortar uma live ou um vídeo longo em cortes verticais para Reels, TikTok ou Shorts, por exemplo "corta essa live em cinco" ou "faz cortes desse vídeo".
---

# Cortar live (Sistema de Cortes)

Transforma um vídeo longo em cortes verticais (1080x1920) com título e, quando possível, legenda.

## Antes de tudo
- Só use vídeo que a pessoa tem permissão para usar (live própria ou de quem autorizou). Se ela não disse, lembre disso em uma frase no final.
- Não prometa views, seguidores nem dinheiro.

## Passo a passo
1. Ache o vídeo (anexo da conversa ou arquivo na pasta de trabalho). Só pergunte se não encontrar nenhum.
2. Decida a quantidade: se a pessoa pediu "em cinco", use 5. Sem número, use 5. Duração padrão: 40 segundos por corte.
3. Rode (o caminho dos scripts é a pasta `scripts` desta skill):
   `python3 scripts/cortar.py "<video>" --n 5 --dur 40 --out cortes`
   Isso escolhe os momentos com mais energia (áudio mais alto e mais trocas de cena), corta cada um em vertical com fundo desfocado e salva `cortes/corte-1.mp4` ... `corte-5.mp4`, uma imagem `corte-N.jpg` de cada e `cortes/momentos.json`.
4. Olhe cada imagem `corte-N.jpg` e escreva um título curto para cada corte: até 4 palavras, em MAIÚSCULAS, só com o que aparece de verdade. Não invente fatos. Salve em `cortes/titulos.json`, por exemplo `["PERSEGUIÇÃO", "OLHA ISSO"]`.
5. Rode:
   `python3 scripts/titular.py cortes --titulos cortes/titulos.json --legenda`
   Isso coloca o título no topo de cada corte e, se o ambiente tiver Whisper (faster-whisper ou whisper), coloca a legenda. Sem Whisper, entrega só com título e avisa a pessoa.
6. Entregue os arquivos `cortes/final/corte-N.mp4` e diga em poucas linhas o que foi feito (e se a legenda não foi possível).

## Se der erro
- Sem `ffmpeg`: tente `pip install imageio-ffmpeg` ou peça para a pessoa instalar o ffmpeg, e diga claramente o que faltou.
- Vídeo curto demais para N cortes: o script reduz a duração sozinho; avise a pessoa.
