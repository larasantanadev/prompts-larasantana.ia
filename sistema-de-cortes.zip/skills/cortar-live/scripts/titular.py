#!/usr/bin/env python3
"""Coloca título (e legenda, se houver Whisper) nos cortes."""
import argparse, glob, json, os, re, shutil, subprocess, sys, tempfile

FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
         "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "/Library/Fonts/Arial Bold.ttf",
         "C:/Windows/Fonts/arialbd.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"]


def ffmpeg_bin():
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        sys.exit("ffmpeg não encontrado.")


def wrap(t, w=16):
    words, lines, cur = t.split(), [], ""
    for x in words:
        if cur and len(cur) + 1 + len(x) > w:
            lines.append(cur)
            cur = x
        else:
            cur = (cur + " " + x).strip()
    lines.append(cur)
    return "\n".join(lines)


def transcribe(path, srt):
    """Gera SRT com faster-whisper ou whisper. Retorna True se deu certo."""
    segs = None
    try:
        from faster_whisper import WhisperModel
        m = WhisperModel("small", device="cpu", compute_type="int8")
        segs = [(s.start, s.end, s.text.strip()) for s in m.transcribe(path, language="pt")[0]]
    except Exception:
        try:
            import whisper
            r = whisper.load_model("small").transcribe(path, language="pt")
            segs = [(s["start"], s["end"], s["text"].strip()) for s in r["segments"]]
        except Exception:
            return False
    if not segs:
        return False

    def ts(x):
        h, m_, s = int(x // 3600), int(x % 3600 // 60), x % 60
        return f"{h:02d}:{m_:02d}:{s:06.3f}".replace(".", ",")
    with open(srt, "w", encoding="utf-8") as f:
        for i, (a, b, t) in enumerate(segs, 1):
            f.write(f"{i}\n{ts(a)} --> {ts(b)}\n{t}\n\n")
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--titulos", required=True)
    ap.add_argument("--legenda", action="store_true")
    a = ap.parse_args()
    ff = ffmpeg_bin()
    font = next((f for f in FONTS if os.path.exists(f)), None)
    if not font:
        sys.exit("Nenhuma fonte encontrada para o título. Instale uma fonte (ex.: DejaVu Sans Bold).")
    titulos = json.load(open(a.titulos, encoding="utf-8"))
    out_dir = os.path.join(a.pasta, "final")
    os.makedirs(out_dir, exist_ok=True)
    clips = sorted(glob.glob(os.path.join(a.pasta, "corte-*.mp4")), key=lambda p: int(re.findall(r"\d+", os.path.basename(p))[0]))
    got_caps = 0
    for i, clip in enumerate(clips):
        title = titulos[i] if i < len(titulos) else f"CORTE {i + 1}"
        tmp = tempfile.mkdtemp()
        tf = os.path.join(tmp, "t.txt")
        open(tf, "w", encoding="utf-8").write(wrap(title.upper()))
        vf = (f"drawtext=fontfile='{font}':textfile='{tf}':fontsize=78:fontcolor=white:borderw=7:bordercolor=black:"
              f"line_spacing=10:x=(w-text_w)/2:y=230")
        if a.legenda:
            srt = os.path.join(tmp, "l.srt")
            if transcribe(clip, srt):
                p = srt.replace("\\", "/").replace(":", "\\:")
                vf += f",subtitles='{p}':force_style='Alignment=2,MarginV=330,Fontsize=16,Bold=1,Outline=3'"
                got_caps += 1
        out = os.path.join(out_dir, os.path.basename(clip))
        r = subprocess.run([ff, "-v", "error", "-y", "-i", clip, "-vf", vf, "-c:v", "libx264", "-preset", "veryfast",
                            "-crf", "21", "-c:a", "copy", "-movflags", "+faststart", out], capture_output=True, text=True)
        if r.returncode:
            sys.exit("Erro ao colocar o título: " + r.stderr[-400:])
        print("ok", out)
    if a.legenda and not got_caps:
        print("AVISO: sem Whisper neste ambiente, os cortes saíram só com título.")


if __name__ == "__main__":
    main()
