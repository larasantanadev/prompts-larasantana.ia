#!/usr/bin/env python3
"""Escolhe os melhores momentos de um vídeo longo e corta em vertical 1080x1920."""
import argparse, json, os, re, shutil, subprocess, sys, tempfile


def ffmpeg_bin():
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        sys.exit("ffmpeg não encontrado. Instale o ffmpeg (ou: pip install imageio-ffmpeg).")


FF = None


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def duration(video):
    r = run([FF, "-hide_banner", "-i", video])
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr)
    if not m:
        sys.exit("Não consegui ler a duração do vídeo.")
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


def audio_rms(video):
    """RMS (dB) por segundo."""
    af = "asetnsamples=n=8000:p=0,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-"
    r = run([FF, "-v", "error", "-i", video, "-vn", "-ac", "1", "-ar", "8000", "-af", af, "-f", "null", "-"])
    vals = []
    for line in r.stdout.splitlines():
        m = re.search(r"RMS_level=(-?[\d.]+|-?inf)", line)
        if m:
            v = m.group(1)
            vals.append(-90.0 if "inf" in v else max(-90.0, float(v)))
    return vals


def scene_times(video):
    vf = "fps=2,scale=320:-2,select='gt(scene,0.2)',metadata=print:file=-"
    r = run([FF, "-v", "error", "-i", video, "-an", "-vf", vf, "-f", "null", "-"])
    return [float(x) for x in re.findall(r"pts_time:([\d.]+)", r.stdout)]


def zscore(xs):
    if not xs:
        return xs
    mu = sum(xs) / len(xs)
    sd = (sum((x - mu) ** 2 for x in xs) / len(xs)) ** 0.5 or 1.0
    return [(x - mu) / sd for x in xs]


def pick(total, rms, scenes, n, dur):
    step = 5
    starts = [s for s in range(int(total * 0.02), int(total - dur) + 1, step)] or [0]
    sc = [0] * (int(total) + 2)
    for t in scenes:
        sc[min(int(t), len(sc) - 1)] += 1
    a, b = [], []
    for s in starts:
        seg = rms[s:s + int(dur)] or [-90.0]
        a.append(sum(seg) / len(seg))
        b.append(sum(sc[s:s + int(dur)]))
    za, zb = zscore(a), zscore(b)
    ranked = sorted(range(len(starts)), key=lambda i: za[i] + 0.5 * zb[i], reverse=True)
    chosen = []
    for i in ranked:
        s = starts[i]
        if all(abs(s - c) >= dur for c in chosen):
            chosen.append(s)
        if len(chosen) == n:
            break
    return sorted(chosen)


def main():
    global FF
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--n", type=int, default=5)
    ap.add_argument("--dur", type=float, default=40)
    ap.add_argument("--out", default="cortes")
    ap.add_argument("--fit", choices=["blur", "crop"], default="blur")
    a = ap.parse_args()
    FF = ffmpeg_bin()
    if not os.path.exists(a.video):
        sys.exit("Vídeo não encontrado: " + a.video)
    total = duration(a.video)
    dur = a.dur
    if total < a.n * dur * 1.05:
        dur = max(10.0, round(total / (a.n * 1.05), 1))
        print(f"Vídeo curto: usando {dur} s por corte.")
    rms, scenes = audio_rms(a.video), scene_times(a.video)
    starts = pick(total, rms, scenes, a.n, dur)
    os.makedirs(a.out, exist_ok=True)
    if a.fit == "blur":
        fc = ("[0:v]split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=30:5[bg];"
              "[b]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]")
    else:
        fc = "[0:v]scale=-2:1920,crop=1080:1920,format=yuv420p[v]"
    info = []
    for i, s in enumerate(starts, 1):
        out = os.path.join(a.out, f"corte-{i}.mp4")
        r = run([FF, "-v", "error", "-y", "-ss", str(s), "-t", str(dur), "-i", a.video, "-filter_complex", fc,
                 "-map", "[v]", "-map", "0:a?", "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
                 "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out])
        if r.returncode:
            sys.exit("Erro ao cortar: " + r.stderr[-400:])
        run([FF, "-v", "error", "-y", "-ss", str(dur / 2), "-i", out, "-frames:v", "1", "-vf", "scale=540:-2",
             os.path.join(a.out, f"corte-{i}.jpg")])
        info.append({"corte": i, "inicio_s": s, "duracao_s": dur, "arquivo": out})
    json.dump(info, open(os.path.join(a.out, "momentos.json"), "w"), ensure_ascii=False, indent=2)
    print(json.dumps(info, ensure_ascii=False))


if __name__ == "__main__":
    main()
